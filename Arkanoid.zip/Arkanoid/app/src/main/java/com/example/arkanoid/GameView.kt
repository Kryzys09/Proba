package com.example.arkanoid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.ContextMenu
import android.view.MotionEvent
import android.view.View

class GameView(context: Context): View(context) {
    var score = 0
    var gameOn: Boolean = true
    var ball: Ball = Ball(100f, 100f, 20f)
    var isInitialized = false
    val ballPaint: Paint = Paint()
    val brickPaint: Paint = Paint()
    var platform: Brick = Brick(0f, 0f, 0f, 0f)
    var bricks: ArrayList<Brick> = ArrayList()
    var brickWidth: Float = 0f
    var brickHeight: Float = 0f
    var gameThread: GameThread = GameThread(this)

    fun initialize(){
        ballPaint.color = Color.BLACK
        platform = Brick(0f, height-60f, 200f, height-30f)
        ball.y = platform.top - 20f
        ball.x = 20f
        ball.speed = 5f
        ball.xDirection = true
        ball.yDirection = false
        setupBricks()
        gameThread = GameThread(this)
        gameThread.start()
        isInitialized = true
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        if(!isInitialized) {
            initialize()
        }

        canvas.drawCircle(ball.x, ball.y, ball.radius, ballPaint)
        canvas.drawRect(platform.left, platform.top, platform.right, platform.bottom, ballPaint)
        drawBricks(canvas)

    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val radius = (platform.right - platform.left)/2
        platform.left = event.x - radius
        platform.right = event.x + radius
        invalidate()
        return true
    }

    fun setupBricks(){
        bricks = ArrayList()
        brickWidth = width/10f
        brickHeight = height/10f
        for(i in 0..4){
            for(j in 0..9){
                bricks.add(Brick(j*brickWidth, i*brickHeight, (j+1)*brickWidth, (i+1)*brickHeight))
            }
        }
    }

    fun drawBricks(canvas: Canvas){
        brickPaint.strokeWidth = 5f
        for(i in bricks){
            brickPaint.color = Color.BLACK
            brickPaint.style = Paint.Style.STROKE
            canvas.drawRect(i.left, i.top, i.right, i.bottom, brickPaint)

            brickPaint.color = Color.YELLOW
            brickPaint.style = Paint.Style.FILL
            canvas.drawRect(i.left, i.top, i.right, i.bottom, brickPaint)
        }
    }
}