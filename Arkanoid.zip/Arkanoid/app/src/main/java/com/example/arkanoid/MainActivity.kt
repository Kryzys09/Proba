package com.example.arkanoid

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var currentScore = 999

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gameView = GameView(this)
        setContentView(R.layout.activity_main)
        loadData()


        button.text = "restart"
        button.setOnClickListener{
            gameView.initialize()
            if(currentScore > gameView.score) {
                saveData(gameView.score)
            }
            loadData()
            gameView.score = 0
            textView.text = "highest score: " + currentScore.toString()
        }

        textView.text = "highest score: " + currentScore.toString()
        mainLinear.addView(gameView)
    }

    private fun saveData(score: Int){
        var sharedPreferences: SharedPreferences = getSharedPreferences("SHARED_PREFS", Context.MODE_PRIVATE)
        var editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putInt("SCORE", score)
        editor.apply()
    }

    private fun loadData(){
        var sharedPreferences: SharedPreferences = getSharedPreferences("SHARED_PREFS", Context.MODE_PRIVATE)
        currentScore = sharedPreferences.getInt("SCORE", 999)
    }

}
