package com.example.arkanoid

import android.graphics.Paint

class Brick(var left: Float, var top: Float, var right: Float, var bottom: Float) {
    fun isInside(xBall: Float, yBall: Float, radius: Float): Boolean{
        if(xBall + radius >= left && xBall - radius<=right && yBall + radius >=top && yBall - radius<=bottom){
            return true
        }
        return false
    }
}