package com.example.arkanoid

class GameThread(val gameView: GameView): Thread() {
    val frameRate: Long = 10
    var gameOn = true
    public override fun run(){
        while(gameOn){
            if(gameView.bricks.size == 0){
                gameOn = false
            }
            gameView.ball.move()
            checkMoves()
            gameView.invalidate()
            Thread.sleep(frameRate)
        }
    }

    fun checkMoves(){
        var removeBrick: Brick = Brick(0f, 0f, 0f, 0f)
        var brickToRemove = false
        var direction = 0
        if(gameView.ball.x < 0 || gameView.ball.x > gameView.width){
            gameView.ball.xDirection = !gameView.ball.xDirection
        }
        if(gameView.ball.y > gameView.height){
            gameOn = false
            gameView.score = 999
        }
        if(gameView.ball.y < 0){
            gameView.ball.yDirection = !gameView.ball.yDirection
        }
        for(i in gameView.bricks){
            if(i.isInside(gameView.ball.x, gameView.ball.y, gameView.ball.radius)){
                removeBrick = i
                brickToRemove = true
                if(i.isInside(gameView.ball.x+gameView.ball.radius, gameView.ball.y, 0f) || i.isInside(gameView.ball.x-gameView.ball.radius, gameView.ball.y, 0f))
                    gameView.ball.xDirection = !gameView.ball.xDirection
                else if(i.isInside(gameView.ball.x, gameView.ball.y-gameView.ball.radius, 0f) || i.isInside(gameView.ball.x, gameView.ball.y+gameView.ball.radius, 0f))
                    gameView.ball.yDirection = !gameView.ball.yDirection
                else{
                    gameView.ball.xDirection = !gameView.ball.xDirection
                    gameView.ball.yDirection = !gameView.ball.yDirection
                }
            }
        }
        if(brickToRemove) {
            gameView.bricks.remove(removeBrick)
        }else if(gameView.platform.isInside(gameView.ball.x, gameView.ball.y, gameView.ball.radius)){
            gameView.ball.yDirection = false
            when(gameView.ball.x - gameView.platform.left){
                in 0..20 -> {
                    gameView.ball.speed = 10f
                    gameView.ball.xDirection = false
                }
                in 20..40 -> {
                    gameView.ball.speed = 8f
                    gameView.ball.xDirection = false
                }
                in 40..60 -> {
                    gameView.ball.speed = 6f
                    gameView.ball.xDirection = false
                }
                in 60..80 -> {
                    gameView.ball.speed = 4f
                    gameView.ball.xDirection = false
                }
                in 80..100 -> {
                    gameView.ball.speed = 2f
                    gameView.ball.xDirection = false
                }
                in 100..120 -> {
                    gameView.ball.speed = 2f
                    gameView.ball.xDirection = true
                }
                in 120..140 -> {
                    gameView.ball.speed = 4f
                    gameView.ball.xDirection = true
                }
                in 140..160 -> {
                    gameView.ball.speed = 6f
                    gameView.ball.xDirection = true
                }
                in 160..180 -> {
                    gameView.ball.speed = 8f
                    gameView.ball.xDirection = true
                }
                in 180..200 -> {
                    gameView.ball.speed = 10f
                    gameView.ball.xDirection = true
                }
            }
            gameView.score++
        }
    }
}