package com.example.arkanoid

class Ball(var x: Float, var y: Float, val radius: Float) {
    var xDirection: Boolean = true
    var yDirection: Boolean = false
    var speed: Float = 2f

    fun move(){
        if(xDirection) {
            x = x + speed
        }else {
            x = x - speed
        }
        if(yDirection) {
            y = y + 2
        }else {
            y = y - 2
        }
    }
}